from tkinter import *
from os import listdir
from os.path import isfile, join
import os


L = []
pos=[0,0]

for f in listdir(os.getcwd()):
	if isfile(join(os.getcwd(),f)):
		L.append(f)
		
x=len(L)-1
for i in reversed(L):
	print(x)
	print(L[x])
	if i.find('.gif') == -1:
		print('poped',L.pop(x))
	x=x-1

root = Tk()
def gotoP():
	print('p')
	pos[0]=pos[0]-1
	if pos[0]<0:
		c=0-pos[0]
		pos[0]=len(L)-c
	photo1=PhotoImage(file=L[pos[0]])
	label1=Label(root,image=photo1)
	label1.image = photo1
	label1.grid(row=0,columnspan=2)
def gotoN():
	print('n')
	pos[0]=pos[0]+1
	if pos[0]>len(L)-1:
		pos[0]=pos[0]%len(L)
	photo2=PhotoImage(file=L[pos[0]])
	label2=Label(root,image=photo2)
	label2.image = photo2
	label2.grid(row=0,columnspan=2)

print(L)
root.wm_title("Kenneth's Image Browser")
previous=Button(root,text='Previous',command=gotoP)
previous.grid(row=3,column=0,sticky=E)
next=Button(root,text='Next',command=gotoN)
next.grid(row=3,column=1,sticky=W)
root.mainloop()
